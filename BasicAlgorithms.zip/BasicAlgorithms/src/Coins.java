import java.util.*;

public class Coins {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String coinsLine = scanner.nextLine();
        LinkedHashMap<Integer, Integer> coinUsage = new LinkedHashMap<>();

        Arrays.stream(coinsLine
            .replaceAll("Coins: ", "")
            .split(", "))
            .map(Integer::parseInt)
            .sorted((f, s) -> Integer.compare(s, f))
            .forEach((num) -> coinUsage.put(num, 0));

        String[] line = scanner.nextLine().split(": ");
        int sum = Integer.parseInt(line[1]);

        int totalCount = 0;

        for (Integer coinValue : coinUsage.keySet()) {
            int count = sum / coinValue;
            coinUsage.replace(coinValue, count);

            totalCount += count;
            //sum -= count * coinValue;
        }

        if (sum > 0) {
            System.out.println("Error");
            return;
        }

        System.out.println("Number of coins to take: " + totalCount);
        coinUsage.entrySet()
                .stream()
                .filter((entry) -> entry.getValue() != 0)
                .forEach((entry) -> System.out.println(
                        entry.getValue() +
                        " coin(s) with value " +
                        entry.getKey()));
    }
}

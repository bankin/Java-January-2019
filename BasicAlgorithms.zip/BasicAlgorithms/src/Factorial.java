import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Scanner;

public class Factorial {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int factorial = Integer.parseInt(scanner.nextLine());

        System.out.println(fact(0));
    }

    private static long fact(long factorial) {
        if (factorial == 1) {
            return 1;
        }

        return factorial * fact(factorial - 1);
    }
}

import org.junit.Before;
import org.junit.Test;

import java.util.Iterator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class InstockTests {
    private final String DEFAULT_PRODUCT_LABEL = "Label";
    private final int DEFAULT_PRODUCT_QUANTITY = 200;
    private final double DEFAULT_PRODUCT_PRICE = 2.5;

    private final Product third = new Product(DEFAULT_PRODUCT_LABEL + "3", 10, 10);

    private Product product;
    private Product second;
    private Instock stock;

    @Before
    public void setup() {
        this.product = new Product(DEFAULT_PRODUCT_LABEL, DEFAULT_PRODUCT_PRICE, DEFAULT_PRODUCT_QUANTITY);
        this.second = new Product(DEFAULT_PRODUCT_LABEL + "2", 20, 10);
        this.stock = new Instock();
    }

    @Test
    public void shouldAddProduct() {
        this.stock.add(product);

        assertTrue(this.stock.contains(product));
    }

    @Test
    public void shouldHaveNonZeroCountAfterProductAdd() {
        this.stock.add(product);

        assertEquals(1, this.stock.getCount());
    }

    @Test
    public void shouldHaveCountEqualsToProductsAdded() {
        this.stock.add(product);
        this.stock.add(product);
        this.stock.add(product);

        assertEquals(3, this.stock.getCount());
    }

    @Test
    public void shouldReturnFalseIfProductNotContained() {
        assertFalse(this.stock.contains(product));
    }

    @Test
    public void containsShouldReturnTrueIfProductLabelsMatch() {
        this.second.setLabel(DEFAULT_PRODUCT_LABEL);
        this.stock.add(this.second);

        assertTrue(this.stock.contains(product));
    }

    @Test
    public void shouldReturnCorrectProductByInsertionOrderWhenSingleProduct() {
        this.stock.add(product);

        Product actual = this.stock.find(1);

        assertEquals(product, actual);
    }

    @Test
    public void shouldReturnCorrectProductByInsertionOrderWhenMultipleProducts() {
        seedStock();

        Product actual = this.stock.find(3);

        assertEquals(third, actual);
    }

    @Test(expected = IndexOutOfBoundsException.class)
    public void shouldThrowExceptionWhenFindCalledWithInvalidIndex() {
        this.stock.find(1);
    }

    @Test
    public void shouldAddQuantityToExistingProduct() {
        this.stock.add(product);

        this.stock.changeQuantity(product.getLabel(), DEFAULT_PRODUCT_QUANTITY);
        Product actual = this.stock.find(1);

        assertEquals(2 * DEFAULT_PRODUCT_QUANTITY, actual.getQuantity());
    }

    @Test
    public void shouldAddQuantityToExistingProductMultipleTimes() {
        this.stock.add(product);

        this.stock.changeQuantity(product.getLabel(), DEFAULT_PRODUCT_QUANTITY);
        this.stock.changeQuantity(product.getLabel(), DEFAULT_PRODUCT_QUANTITY);
        this.stock.changeQuantity(product.getLabel(), DEFAULT_PRODUCT_QUANTITY);
        Product actual = this.stock.find(1);

        assertEquals(4 * DEFAULT_PRODUCT_QUANTITY, actual.getQuantity());
    }

    @Test(expected = IllegalArgumentException.class)
    public void quantityShouldThrowExceptionIfProductDoesNotExist() {
        this.stock.changeQuantity(product.getLabel(), DEFAULT_PRODUCT_QUANTITY);
    }

    @Test
    public void findByLabelShouldReturnProduct() {
        this.stock.add(product);

        Product actual = this.stock.findByLabel(product.getLabel());

        assertEquals(actual, product);
    }

    @Test
    public void findByLabelShouldReturnCorrectResultForMultipleProducts() {
        seedStock();

        Product actual = this.stock.findByLabel(DEFAULT_PRODUCT_LABEL + "2");

        assertEquals(second, actual);
    }

    @Test(expected = IllegalArgumentException.class)
    public void findByLabelShouldThrowExceptionIfLabelDoesNotExist() {
        this.stock.findByLabel(product.getLabel());
    }

    @Test
    public void shouldReturnValidResultForZeroProductsInFindFirstByAlphabeticalOrder() {

        this.stock.add(second);
        this.stock.add(third);
        this.stock.add(product);

        Iterable<Product> actual = this.stock.findFirstByAlphabeticalOrder(0);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void shouldReturnValidResultForEmptyStockInFindFirstByAlphabeticalOrder() {
        Iterable<Product> actual = this.stock.findFirstByAlphabeticalOrder(0);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void shouldReturnValidResultForNegativeCountInFindFirstByAlphabeticalOrder() {
        Iterable<Product> actual = this.stock.findFirstByAlphabeticalOrder(-1);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void shouldReturnValidResultForGreaterCountInFindFirstByAlphabeticalOrder() {
        this.stock.add(second);
        this.stock.add(third);
        this.stock.add(product);

        Iterable<Product> actual = this.stock.findFirstByAlphabeticalOrder(5);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void shouldReturnValidResultForFindFirstByAlphabeticalOrder() {
        this.stock.add(second);
        this.stock.add(third);
        this.stock.add(this.product);

        Product[] sorted = { this.product, second, third};

        Iterable<Product> actual = this.stock.findFirstByAlphabeticalOrder(3);

        assertArrayAndIterable(sorted, actual);
    }

    @Test
    public void findAllInPriceRangeShouldReturnEmptyIterableForEmptyStock() {
        Iterable<Product> actual = this.stock.findAllInRange(5, 15);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void findAllInPriceRangeShouldReturnEmptyIterableIfNoneMatchesThePrice() {
        this.stock.add(this.product);

        Iterable<Product> actual = this.stock.findAllInRange(5, 15);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void findAllInPriceRangeShouldReturnEmptyIterableForNegativePrices() {
        this.stock.add(this.product);

        Iterable<Product> actual = this.stock.findAllInRange(-5, -15);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void findAllInPriceRangeShouldReturnCorrectResult() {
        seedStock();

        Iterable<Product> actual = this.stock
                .findAllInRange(DEFAULT_PRODUCT_PRICE - 1, DEFAULT_PRODUCT_PRICE + 1);

        Iterator<Product> iterator = actual.iterator();

        assertTrue(iterator.hasNext());
        assertEquals(product, iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void findAllInPriceRangeShouldReturnCorrectResultForHigherBoundEdge() {
        seedStock();

        Iterable<Product> actual = this.stock
                .findAllInRange(DEFAULT_PRODUCT_PRICE - 1, DEFAULT_PRODUCT_PRICE);

        Iterator<Product> iterator = actual.iterator();

        assertTrue(iterator.hasNext());
        assertEquals(product, iterator.next());
        assertFalse(iterator.hasNext());
    }

    @Test
    public void findAllInPriceRangeShouldSortCorrectly() {
        seedStock();

        Iterable<Product> actual = this.stock.findAllInRange(0, 30);

        Product[] sorted = { second, third, this.product };

        assertArrayAndIterable(sorted, actual);
    }

    @Test
    public void findAllByPriceRangeShouldReturnEmptyForInvalidPrice() {
        seedStock();

        Iterable<Product> actual = this.stock.findAllByPrice(0);

        assertFalse(actual.iterator().hasNext());
    }

    @Test
    public void findAllByPriceRangeShouldReturnCorrectResult() {
        seedStock();

        Iterable<Product> actual = this.stock
                .findAllByPrice(DEFAULT_PRODUCT_PRICE);

        Iterator<Product> iterator = actual.iterator();

        assertTrue(iterator.hasNext());
        assertEquals(product, iterator.next());
        assertFalse(iterator.hasNext());
    }

    private void assertArrayAndIterable(Product[] sorted, Iterable<Product> actual) {
        Iterator<Product> iterator = actual.iterator();
        assertTrue(iterator.hasNext());
        int i = 0;
        while (iterator.hasNext()) {
            assertEquals(sorted[i++], iterator.next());
        }
    }

    private void seedStock() {
        this.stock.add(this.product);
        this.stock.add(this.second);
        this.stock.add(this.third);
    }
}

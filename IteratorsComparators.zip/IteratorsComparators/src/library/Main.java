package library;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {

    public static void main(String[] args) {
        Book book = new Book("War & Peace", 1999, "Gosho");
        Book book1 = new Book("Harry Potter", 1999);
        Book book2 = new Book("Bai Ganio", 1999, "Gosho3", "Gosho1", "Gosho2");

        book.compareTo(book2);



        Library library = new Library(book, book1, book2);

        for (Book current : library) {
            System.out.println(current.getTitle());
        }

        BookComparator comp = new BookComparator();
        comp.compare(book, book2);
    }
}

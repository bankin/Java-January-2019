package library;

import java.util.Comparator;

public class BookComparator implements Comparator<Book> {
    @Override
    public int compare(Book o1, Book o2) {
        if (o1 == null && o2 == null) { return 0; }
        if (o1 == null) { return -1; }
        if (o2 == null) { return 1; }

        int titleCompare = o1.getTitle().compareTo(o2.getTitle());
        return titleCompare != 0 ? titleCompare : o2.getYear() - o1.getYear();
    }
}
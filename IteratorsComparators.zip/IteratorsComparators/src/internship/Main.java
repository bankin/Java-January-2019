package internship;

import java.util.ArrayDeque;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int problemsCount = Integer.parseInt(scanner.nextLine());
        int candidatesCount = Integer.parseInt(scanner.nextLine());

        ArrayDeque<String> problems = new ArrayDeque<>();
        ArrayDeque<String> candidates = new ArrayDeque<>();

        for (int i = 0; i < problemsCount; i++) {
            String problemName = scanner.nextLine();

            problems.addFirst(problemName);
        }

        for (int i = 0; i < candidatesCount; i++) {
            String candidateName = scanner.nextLine();

            if (isValidName(candidateName)) {
                candidates.offer(candidateName);
            }
        }

        while (candidates.size() > 1 && problems.size() > 0) {
            String currentCandidate = candidates.poll();
            String currentProblem = problems.poll();

            if (isProblemSolved(currentCandidate, currentProblem)) {
                System.out.printf("%s solved %s.%n", currentCandidate, currentProblem);
                candidates.offer(currentCandidate);
            } else {
                System.out.printf("%s failed %s.%n", currentCandidate, currentProblem);
                problems.offer(currentProblem);
            }
        }

        if (candidates.size() == 1) {
            System.out.println(candidates.poll() + " gets the job!");
        } else {
            while (candidates.size() > 0) {
                String name = candidates.poll();

                System.out.print(name);
                if (candidates.size() > 0) {
                    System.out.println(",");
                }
            }
        }
    }

    private static boolean isProblemSolved(String candidate, String problem) {
        int candidateSum = getStringSum(candidate);
        int problemSum = getStringSum(problem);

        return candidateSum > problemSum;
    }

    private static int getStringSum(String string) {
        int sum = 0;
        for (int i = 0; i < string.length(); i++) {
            sum += string.charAt(i);
        }

        return sum;
    }

    private static boolean isValidName(String name) {
        return name.matches("[A-Z][a-z]+ [A-Z][a-z]+");
    }
}

package monopoly;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] s = scanner.nextLine().split(" ");
        int rows = Integer.parseInt(s[0]);
        int cols = Integer.parseInt(s[1]);

        String[][] field = new String[rows][cols];

        for (int i = 0; i < rows; i++) {
            field[i] = scanner.nextLine().split("");
        }

        int playerHotels = 0;
        int playerMoney = 50;
        int turnNumber = 0;
        for (int i = 0; i < rows; i++) {
            int startIndex = (i + 1) % 2 == 0 ? cols - 1 : 0;

            for (int j = startIndex; hasRowEnded(j, cols, i + 1); j += getRowValue(i + 1)) {
                char currentAction = field[i][j].charAt(0);

                switch (currentAction) {
                    case 'H':
                        playerHotels++;
                        System.out.printf("Bought a hotel for %d. Total hotels: %d.%n",
                                playerMoney, playerHotels);
                        playerMoney = 0;
                        break;
                    case 'J':
                        System.out.printf("Gone to jail at turn %d.%n", turnNumber);
                        turnNumber += 2;
                        playerMoney += playerHotels * 10 * 2;
                        break;
                    case 'F':
                        break;
                    case 'S':
                        int moneyToGive = (i + 1) * (j + 1);

                        if (moneyToGive > playerMoney) {
                            System.out.printf("Spent %d money at the shop.%n", playerMoney);
                            playerMoney = 0;
                        } else {
                            System.out.printf("Spent %d money at the shop.%n", moneyToGive);
                            playerMoney -= moneyToGive;
                        }

                        break;
                }

                playerMoney += playerHotels * 10;

                turnNumber++;
            }
        }

        System.out.println("Turns " + (turnNumber));
        System.out.println("Money " + playerMoney);
    }

    private static int getRowValue(int currentRow) {
        return currentRow % 2 == 0 ? -1 : 1;
    }

    private static boolean hasRowEnded(int currentColumn, int columnCount, int currentRow) {
        if (currentRow % 2 == 0) {
            return currentColumn >= 0;
        }

        return currentColumn < columnCount;
    }
}

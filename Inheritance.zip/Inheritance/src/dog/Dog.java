package dog;

public class Dog extends Animal {

    public String bark() {
        return "barking...";
    }
}

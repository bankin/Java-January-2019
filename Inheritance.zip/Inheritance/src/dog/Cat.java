package dog;

public class Cat extends Animal {

    public String meow() {
        return "meowing...";
    }
}

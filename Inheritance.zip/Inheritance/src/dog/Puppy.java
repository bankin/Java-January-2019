package dog;

public class Puppy extends Dog {

    public String weep() {
        return "weeping...";
    }
}

package dog;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;



public class Animal {
    public String eat() {
        return "eating...";
    }
}

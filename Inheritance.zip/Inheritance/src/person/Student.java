package person;

public class Student extends Person {
    private double averageGrade;

    Student(String name) {
        super(name);
    }
}

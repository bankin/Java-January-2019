package carinfo;

import java.util.Scanner;
import java.util.stream.IntStream;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int carCount = Integer.parseInt(scanner.nextLine());

//        IntStream
//            .rangeClosed(1, carCount)
//            .boxed()
//            .map(n -> scanner.nextLine().split(" "))
//            .map(data -> new Car(data[0], data[1], Integer.parseInt(data[2])))
//            .forEach(car -> System.out.println(car.getInfo()));

        IntStream
            .rangeClosed(1, carCount)
            .boxed()
            .map(n -> scanner.nextLine().split(" "))
            .map(data -> {
                Car current;
                if (data.length == 3) {
                    current = new Car(
                            data[0], data[1], Integer.parseInt(data[2]));
                } else {
                    current = new Car(data[0]);
                }

                return current;
            })
            .forEach(car -> System.out.println(car.getInfo()));


//        for (int i = 0; i < carCount; i++) {
//            String[] carParts = scanner.nextLine().split(" ");
//            Car current;
//
//            if (carParts.length == 3) {
//                current = new Car(
//                        carParts[0], carParts[1], Integer.parseInt(carParts[2]));
//            } else {
//                current = new Car(carParts[0]);
//            }
//
//            System.out.println(current.getInfo());
//        }
    }
}

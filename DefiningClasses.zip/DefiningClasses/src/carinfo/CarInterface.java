package carinfo;

public interface CarInterface {

    String setName(String name);
}

package backaccount;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] lineArguments = scanner.nextLine().split(" ");
        String command = lineArguments[0];

        HashMap<Integer, BankAccount> accounts = new HashMap<>();

        Client client = new Client();
        while (!command.equals("End")) {
            client.setCurrentCommand(lineArguments[0]);

            switch (command) {
                case "Deposit":
                    int accountId = Integer.parseInt(lineArguments[1]);
                    double amount = Double.parseDouble(lineArguments[2]);
                    client.setAccountId(accountId);
                    client.setAmount(amount);
                    break;
                case "SetInterest":
                    double interestRate = Double.parseDouble(lineArguments[1]);

                    client.setInterest(interestRate);
                    break;
                case "GetInterest":
                    int accountId2 = Integer.parseInt(lineArguments[1]);
                    int years = Integer.parseInt(lineArguments[2]);

                    client.setAccountId(accountId2);
                    client.setYears(years);
                break;
            }

            String result = client.run();

            if (!result.isEmpty()) {
                System.out.println(result);
            }

            lineArguments = scanner.nextLine().split(" ");
            command = lineArguments[0];
        }
    }
}

package backaccount;

import java.util.HashMap;

public class Client {
    private HashMap<Integer, BankAccount> accounts;
    private String currentCommand;
    private int accountId;
    private double interest;
    private double amount;
    private int years;

    public Client() {
        this.accounts = new HashMap<>();
    }

    public void setCurrentCommand(String currentCommand) {
        this.currentCommand = currentCommand;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setYears(int years) {
        this.years = years;
    }

    public String run() {
        switch (this.currentCommand) {
            case "Create": this.createAccount(); break;
            case "Deposit": this.deposit(); break;
            case "SetInterest": BankAccount.setInterestRate(this.interest); break;
            case "GetInterest": this.getInterest(); break;
        }

        return "";
    }

    private void createAccount() {
        BankAccount account = new BankAccount();
        this.accounts.put(account.getId(), account);

//        result = "Account ID" + account.getId() + " created";
    }

    private void deposit() {
        BankAccount currentAccount = this.accounts.get(this.accountId);
        if (currentAccount == null) {
//            result = "Account does not exist";
            return;
        }
        currentAccount.deposit(this.amount);

        this.accounts.put(this.accountId, currentAccount);
//      result = String.format("Deposited %.0f to ID%d", amount, accountId);
    }

    private void getInterest() {
        BankAccount currentAccount = this.accounts.get(this.accountId);
        if (currentAccount == null) {
//            result = "Account does not exist";
            return;
        }

        double currentAccountInterest = currentAccount.getInterestRate(years);

//                    result = String.format("%.2f", currentAccountInterest);
    }
}

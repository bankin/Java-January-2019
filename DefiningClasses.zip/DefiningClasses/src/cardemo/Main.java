package cardemo;

public class Main {

    public static void main(String[] args) {

        Car honda = new Car();
        Car vw = new Car();
        vw.setMake("VW");
        vw.setModel("Golf ||");
        vw.setHorsePower(100);

        honda.setMake("Honda");
        honda.setModel("Civic");
        honda.setHorsePower(101);

        System.out.printf("The car is: %s %s - %d.%n",
                vw.getMake(), vw.getModel(), vw.getHorsePower());
        System.out.printf("Make: %s Model: %s HP: %d%n",
                honda.getMake(), honda.getModel(), honda.getHorsePower());


    }
}

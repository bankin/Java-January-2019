import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;

class MainHuman extends Human {
    List<Human> parents;
    List<Human> children;

    MainHuman(String name, String birthDate) {
        super(name, birthDate);

        this.parents = new ArrayList<>();
        this.children = new ArrayList<>();
    }

    MainHuman(Human human) {
        this(human.name, human.birthDate);
    }

    @Override
    public String toString() {
        System.out.println(super.toString());
        System.out.println("Parents:");
        this.parents.forEach(p -> System.out.printf("%s %s%n", p.name, p.birthDate));
        System.out.println("Children:");
        this.children.forEach(c -> System.out.printf("%s %s%n", c.name, c.birthDate));

        return "";
    }
}

class Human {
    String name;
    String birthDate;

    Human(String name, String birthDate) {
        this.name = name;
        this.birthDate = birthDate;
    }

    @Override
    public String toString() {
        return String.format("%s %s", this.name, this.birthDate);
    }
}

public class Main {

    public static List<Human> allHumans = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String personInfo = scanner.nextLine();

        List<String> commands = new ArrayList<>();

        String command = scanner.nextLine();
        while(!command.equals("End")) {
            if (command.contains("-")) {
                commands.add(command);
            } else {
                String[] parts = command.split(" ");

                Human current = new Human(parts[0] + " " + parts[1], parts[2]);

                allHumans.add(current);
            }

            command = scanner.nextLine();
        }

        MainHuman main = new MainHuman(findByNameOrDate(personInfo));

        for (String s : commands) {
            String[] parts = s.split(" - ");

            Human firstHuman = findByNameOrDate(parts[0]);
            Human secondHuman = findByNameOrDate(parts[1]);

            if (firstHuman.name.equals(main.name)) {
                main.children.add(secondHuman);
            } else if (secondHuman.name.equals(main.name)){
                main.parents.add(firstHuman);
            }
        }

        System.out.println(main);
    }

    private static Human findByNameOrDate(String searchToken) {
        return allHumans
                .stream()
                .filter(h -> h.name.equals(searchToken) || h.birthDate.equals(searchToken))
                .findFirst()
                .get();
    }
}

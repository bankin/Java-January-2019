package linkedlist;

public class Node {
    int value;
    Node prev;
    Node next;

    Node(int value) {
        this.value = value;
        this.prev = null;
        this.next = null;
    }

    public int getValue() {
        return this.value;
    }
}

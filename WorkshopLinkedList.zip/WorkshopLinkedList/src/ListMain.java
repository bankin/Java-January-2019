import linkedlist.LinkedList;

public class ListMain {

    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        System.out.println("---------");
        System.out.println(list.isEmpty());

        list.addFirst(5);

        System.out.println(list.getHead().getValue());
        System.out.println(list.getSize());
        System.out.println(list.isEmpty());
        System.out.println("---------");

        list.addFirst(8);

        System.out.println(list.getHead().getValue());
        System.out.println(list.getSize());
        System.out.println(list.isEmpty());
        System.out.println("---------");

        System.out.println(list.getTail().getValue());

        list.addLast(3);
        System.out.println(list.getTail().getValue());
        System.out.println(list.getSize());
        System.out.println("---------");
        list.foreach(System.out::println);
        System.out.println("---------");

        System.out.println(list.removeFirst());
        System.out.println(list.getSize());
        System.out.println(list.getHead().getValue());

        System.out.println("---------");

        System.out.println(list.removeLast());
        System.out.println(list.getSize());
        System.out.println(list.getTail().getValue());

        System.out.println("---------");
        list.foreach(System.out::println);

        list.addFirst(4);
        list.addLast(6);

        int[] arr = list.toArray();
        System.out.println(arr[0] + " " + arr[1] + " " + arr[2]);

        list.addAfter(5, 7);
        System.out.println("---------");
        list.foreach(System.out::println);

        list.addAfter(6, 8);
        System.out.println("---------");
        list.foreach(System.out::println);

        list.addAfter(4, 1);
        System.out.println("---------");
        list.foreach(System.out::println);

//        list.addAfter(10, 8);

        list.removeAfter(4);
        System.out.println("---------");
        list.foreach(System.out::println);

        list.removeAfter(6);
        System.out.println("---------");
        list.foreach(System.out::println);

        list.removeAfter(6);
        System.out.println("---------");
        list.foreach(System.out::println);
    }
}

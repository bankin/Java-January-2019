package carTrip;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CarTest {
    private final String DEFAULT_MODEL = "BMW";
    private final double DEFAULT_CAPACITY = 60;
    private final double DEFAULT_AMOUNT = 10;
    private final double DEFAULT_CONSUMPTION = 9;
    private Car car;

    @Before
    public void before() {
        this.car = new Car(
                DEFAULT_MODEL,
                DEFAULT_CAPACITY,
                DEFAULT_AMOUNT,
                DEFAULT_CONSUMPTION);
    }

    @Test
    public void getModelShouldWorkCorrectly() {
        assertEquals(DEFAULT_MODEL, this.car.getModel());
    }

    @Test(expected = IllegalArgumentException.class)
    public void setModelShouldThrowIfModelIsNull() {
        this.car.setModel(null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setModelShouldThrowIfModelIsEmptyString() {
        this.car.setModel("");
    }

    @Test
    public void setModelShouldSetCorrectly() {
        final String newModel = "Mercedes";
        this.car.setModel(newModel);

        assertEquals(newModel, this.car.getModel());
    }

    @Test
    public void getTankCapacityShouldWorkCorrectly() {
        assertEquals(DEFAULT_CAPACITY, this.car.getTankCapacity(), 0.0);
    }

    @Test
    public void setTankCapacityShouldWorkCorrectly() {
        double newCapacity = 50.0;

        this.car.setTankCapacity(newCapacity);
        assertEquals(newCapacity, this.car.getTankCapacity(), 0.0);
    }

    @Test
    public void getFuelAmountShouldWorkCorrectly() {
        assertEquals(DEFAULT_AMOUNT, this.car.getFuelAmount(), 0.0);
    }

    @Test
    public void setFuelAmountShouldWorkCorrectly() {
        double newCapacity = 50.0;

        this.car.setFuelAmount(newCapacity);
        assertEquals(newCapacity, this.car.getFuelAmount(), 0.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setFuelAmountShouldThrowIfAmountIsGreaterThanCapacity() {
        this.car.setFuelAmount(DEFAULT_CAPACITY + 1);
    }

    @Test
    public void getFuelConsumptionShouldWorkCorrectly() {
        assertEquals(DEFAULT_CONSUMPTION, this.car.getFuelConsumptionPerKm(), 0.0);
    }

    @Test
    public void setFuelConsumptionShouldWorkCorrectly() {
        double newConsumption = 50.0;

        this.car.setFuelConsumptionPerKm(newConsumption);
        assertEquals(newConsumption, this.car.getFuelConsumptionPerKm(), 0.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setFuelConsumptionShouldThrowWithNegativeConsumption() {
        this.car.setFuelConsumptionPerKm(-1);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldThrowIfModelIsEmpty() {
        new Car("", 1.0, 1.0, 1.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldThrowIfModelIsNull() {
        new Car(null, 1.0, 1.0, 1.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldThrowIfFuelAmountGreaterThanCapacity() {
        new Car("Valid", 1.0, 2.0, 1.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void constructorShouldThrowIfFuelConsumptionIsNegative() {
        new Car("Valid", 1.0, 1.0, -1.0);
    }

    @Test(expected = IllegalStateException.class)
    public void e() {
        // Default amount is 10 and consumption is 9/100 so 2km trip
        // would require 18l of fuel
        this.car.drive(2.0);
    }

    @Test
    public void d() {
        this.car.drive(1.0);

        assertEquals(DEFAULT_AMOUNT - DEFAULT_CONSUMPTION, this.car.getFuelAmount(), 0.0);
    }

    @Test
    public void c() {
        String result = this.car.drive(1.0);

        assertEquals("Have a nice trip", result);
    }

    @Test(expected = IllegalStateException.class)
    public void b() {
        this.car.refuel(DEFAULT_CAPACITY + 1);
    }

    @Test
    public void a() {
        double amount = 10.0;

        this.car.refuel(amount);

        assertEquals(amount + DEFAULT_AMOUNT, this.car.getFuelAmount(), 0.0);
    }
}
import java.io.*;

public class ReadSerialize {

    public static void main(String[] args) {
        String basePath = "C:\\Users\\Guest Lector\\Downloads" +
                "\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\" +
                "04. Java-Advanced-Files-and-Streams-Lab-Resources";
        String inputPath = basePath + "\\input.txt";
        String outputPath = basePath + "\\9output.txt";


        FileWriter writer = null;
        try {
            ObjectInputStream objectStream =
                    new ObjectInputStream(new FileInputStream(inputPath));

            Cube restored = (Cube)objectStream.readObject();

            System.out.printf("%s, %f, %f, %f",
                    restored.color,
                    restored.width,
                    restored.height,
                    restored.depth);

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

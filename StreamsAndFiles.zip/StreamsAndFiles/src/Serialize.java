import java.io.*;
import java.util.Scanner;

public class Serialize {

    public static void main(String[] args) {

        Cube cube = new Cube();
        cube.color = "green";
        cube.width = 15.3d;
        cube.height = 12.4d;
        cube.depth = 3d;

        String basePath = "C:\\Users\\Guest Lector\\Downloads" +
                "\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\" +
                "04. Java-Advanced-Files-and-Streams-Lab-Resources";
        String inputPath = basePath + "\\input.txt";
        String outputPath = basePath + "\\9output.txt";


        FileWriter writer = null;
        try {
            ObjectOutputStream objectOutputStream =
                    new ObjectOutputStream(new FileOutputStream(outputPath));

            objectOutputStream.writeObject(cube);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class Cube implements Serializable {
    public String color;
    public double height;
    public double width;
    public double depth;
}

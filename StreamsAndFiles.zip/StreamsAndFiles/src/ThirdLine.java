import java.io.*;
import java.nio.file.Files;

public class ThirdLine {

    public static void main(String[] args) throws IOException {
        String basePath = "C:\\Users\\Guest Lector\\Downloads" +
                "\\04. Java-Advanced-Files-and-Streams-Lab-Resources\\" +
                "04. Java-Advanced-Files-and-Streams-Lab-Resources";
        String inputPath = basePath + "\\input.txt";
        String outputPath = basePath + "\\5output.txt";
        BufferedReader breader = null;
        PrintWriter writer = null;
        int row = 1;

        try {
            breader = new BufferedReader(new FileReader(inputPath));
            writer = new PrintWriter(new FileWriter(outputPath));


            String line = breader.readLine();
            while (line != null) {
                if (row % 3 == 0) {
                    writer.append(line);
                }

                row += 1;
                line = breader.readLine();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (breader != null) {
                breader.close();
            }

            if (writer != null) {
                writer.close();
            }
        }
    }
}

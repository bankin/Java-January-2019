package demo;

public interface Readable {
    void read();

    int readBytes();
}

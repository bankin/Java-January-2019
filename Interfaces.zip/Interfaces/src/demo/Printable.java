package demo;

public interface Printable {
    void print();
}

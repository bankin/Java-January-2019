package demo;

public class Screen implements Printable {
    @Override
    public void print() {
        System.out.println("Print Screen");
    }
}

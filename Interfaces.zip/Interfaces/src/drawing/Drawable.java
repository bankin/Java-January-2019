package drawing;

public interface Drawable {
    void draw();
}

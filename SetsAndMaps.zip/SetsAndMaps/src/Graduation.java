import java.util.*;

public class Graduation {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        TreeMap<String, Double> studentScores = new TreeMap<>();
        int rowCount = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < rowCount; i++) {
            String studentName = scanner.nextLine();
            Double avrgScore = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToDouble(Double::parseDouble)
                    .average()
                    .getAsDouble();

            studentScores.put(studentName, avrgScore);
        }

        for (String studentName : studentScores.keySet()) {
            System.out.println(studentName + " is graduated with " + studentScores.get(studentName));
        }
    }
}

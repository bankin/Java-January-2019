import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.*;

public class AverageGrades {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TreeMap<String, List<Double>> record = new TreeMap<>();

        int gradesCount = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < gradesCount; i++) {
            String[] parts = scanner.nextLine().split(" ");
            String name = parts[0];
            double grade = Double.parseDouble(parts[1]);

            List<Double> currentGrades = new ArrayList<>();

            if (record.containsKey(name)) {
                currentGrades = record.get(name);
            }

            currentGrades.add(grade);
            record.put(name, currentGrades);
        }

        for (String studentName : record.keySet()) {
            System.out.print(studentName + " -> ");
            Double gradeSum = 0d;
            List<Double> studentGrades = record.get(studentName);
            for (Double grade : studentGrades) {
                gradeSum += grade;
                System.out.printf("%.2f ", grade);
            }

            gradeSum = Math.round(gradeSum * 100) / 100.0;

            System.out.printf("(avg: %.2f)\n", Math.round((gradeSum / studentGrades.size()) * 100) / 100.0);
        }
    }
}

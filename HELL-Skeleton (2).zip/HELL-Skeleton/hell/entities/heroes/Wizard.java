package hell.entities.heroes;

public class Wizard extends Heroes {
    public Wizard(String name) {
        super(name, 25, 25, 100, 100, 250);
    }
}

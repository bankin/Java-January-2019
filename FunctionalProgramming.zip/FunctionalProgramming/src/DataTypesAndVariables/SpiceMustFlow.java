package DataTypesAndVariables;

import java.util.Scanner;

public class SpiceMustFlow {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


    }
}

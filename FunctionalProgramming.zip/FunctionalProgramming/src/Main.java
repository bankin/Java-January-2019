import java.util.function.UnaryOperator;

public class Main {

    public static void main(String[] args) {

    }
}
